def iguais(array1, array2):
  return set(array1) == set(array2)

print(iguais([1, 2, 3], [3, 2, 1]))  
print(iguais([1, 2, 2], [2, 1, 1])) 
